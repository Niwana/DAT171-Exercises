Welcome to Card library's documentation!
========================================

This is the documentation for a library of a standard playing card created
for computer assignment 2 in DAT171 Object oriented programming in Python.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

.. automodule:: cardlib
   :members:
   :show-inheritance:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
